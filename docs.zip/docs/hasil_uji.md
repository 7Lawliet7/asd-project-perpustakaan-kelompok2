# Dokumen Hasil Pengujian Manual — Sistem Perpustakaan Mini (Tahap 1)

**Tanggal eksekusi:** Minggu, 25 Oktober 2026
**Perangkat/OS:** Laptop ASUS, Windows
**Versi Python:** 3.13.3
**Dieksekusi oleh:** Joshua Cleon Pangalinan
**Diverifikasi & dipublikasikan oleh:** Dava Syatria Drama
**Perintah jalankan:** `python main.py`
**Lokasi screenshot:** folder `screenshot_uts/` di samping dokumen ini

## Data contoh pengujian

- BK001 / Laskar Pelangi / Andrea Hirata / Novel / 2005
- BK002 / Bumi Manusia / Pramoedya Anantara Toer / Novel / 1980
- BK003 / Clean Code / Robert C. Martin / Teknologi / 2008

## Skenario 1 — Menu utama & pilihan tidak valid

- Langkah: jalankan program, lalu input pilihan `9`
- Hasil: menu 0–6 tampil; muncul pesan "Pilihan tidak valid. Masukkan angka 0 sampai 6."; menu tampil lagi
- Status: lolos
- Screenshot: `01_menu_utama.png`, `02_menu_pilihan_invalid.png`

## Skenario 2 — F1 tambah buku valid

- Langkah: menu 1, input data BK001 lengkap
- Hasil: pesan "Buku 'Laskar Pelangi' dengan kode BK001 berhasil ditambahkan ke koleksi."; pada F2 status tampil `[TERSEDIA]`
- Status: lolos
- Screenshot: `04_f1_tambah_buku_sukses.png`

## Skenario 3 — F1 tolak field teks kosong

- Langkah: menu 1; coba kode kosong, judul kosong, pengarang kosong, genre kosong (empat percobaan)
- Hasil: masing-masing ditolak dengan pesan "Error: ... tidak boleh kosong." lalu kembali ke menu
- Status: lolos
- Screenshot: `05_f1_validasi_kode_dan_judul_kosong.png`, `06_f1_validasi_pengarang_dan_genre_kosong.png`

## Skenario 4 — F1 tolak tahun tidak valid

- Langkah: menu 1; tahun diisi `dua ribu`, lalu `-6`, lalu `2030`
- Hasil: pesan harus angka bulat; harus bilangan bulat positif; tidak boleh lebih besar dari 2026
- Status: lolos
- Screenshot: `07_f1_tahun_berupa_teks.png`, `08_f1_tahun_nol_atau_negatif.png`, `09_f1_tahun_lebih_besar_dari_tahun_ini.png`

## Skenario 5 — F2 koleksi kosong vs berisi

- Langkah: menu 2 saat koleksi kosong; tambah 3 buku contoh; menu 2 lagi
- Hasil: kosong → "Belum ada buku dalam koleksi."; berisi → tabel 7 kolom + "Total buku: 3 | Tersedia: 3 | Dipinjam: 0"
- Status: lolos
- Screenshot: `03_f2_koleksi_kosong.png`, `11_f2_koleksi_isi_dan_ringkasan.png`

## Skenario 6 — F3 semua mode pencarian

- Langkah: cari kode `BK001`; kode `BK999`; judul kata kunci `BUMI`; kata kunci kosong
- Hasil: detail buku BK001; pesan tidak ditemukan untuk BK999; 1 hasil untuk "BUMI" (partial match, case-insensitive); error untuk kata kunci kosong
- Status: lolos
- Screenshot: `12_f3_kode_ditemukan_dan_tidak_ditemukan.png`, `13_f3_judul_partial_case_insensitive.png`, `14_f3_kata_kunci_kosong.png`

## Skenario 7 — F4 update status & pembatalan

- Langkah: update BK001 konfirmasi `y`; update BK002 konfirmasi `n`; update BK001 konfirmasi `y`; coba kode `BK999`
- Hasil: Tersedia→Dipinjam; "Perubahan status dibatalkan." saat `n`; Dipinjam→Tersedia; error kode tidak ditemukan
- Status: lolos
- Screenshot: `15_f4_pinjam_dan_pembatalan.png`, `16_f4_kembali_dan_kode_tidak_ditemukan.png`

## Skenario 8 — F5 filter genre

- Langkah: filter `NOV` (huruf kapital); filter kosong; filter `komedi`
- Hasil: 2 buku untuk "NOV" (partial match, case-insensitive); error genre kosong; "Tidak ada buku dengan genre 'komedi' dalam koleksi."
- Status: lolos
- Screenshot: `17_f5_filter_partial_case_insensitive.png`, `18_f5_genre_kosong_dan_tidak_cocok.png`

## Skenario 9 — F6 aturan hapus

- Langkah: hapus BK002 berstatus Dipinjam; hapus BK003 konfirmasi `n`; hapus kode `BK999`; hapus BK003 konfirmasi `y`
- Hasil: penolakan untuk buku dipinjam beserta alasannya; "Penghapusan dibatalkan."; pesan kode tidak ditemukan; pesan berhasil dihapus
- Status: lolos
- Screenshot: `19_f6_hapus_buku_dipinjam_ditolak.png`, `20_f6_pembatalan_dan_kode_tidak_ditemukan.png`, `21_f6_hapus_sukses.png`

## Skenario 10 — Kembali ke menu & keluar program

- Langkah: perhatikan alur setelah setiap skenario; akhiri dengan menu 0
- Hasil: menu utama selalu tampil kembali setelah fitur selesai; program berakhir dengan pesan "Terima kasih. Program Sistem Perpustakaan Mini selesai."
- Status: lolos
- Screenshot: `22_menu_kembali_dan_program_selesai.png`

## Ringkasan

- Total skenario: 10
- Lolos: 10
- Gagal: 0
- Catatan: seluruh baris "Hasil" di atas ditulis berdasarkan eksekusi nyata di terminal pada tanggal tersebut dan diverifikasi ulang sebelum dipublikasikan ke repository.